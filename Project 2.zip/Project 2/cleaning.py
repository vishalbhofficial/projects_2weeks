import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("ShartankIndiaAllPitches.csv")

# Clean column names
df.columns = df.columns.str.strip()

# Manually set correct column names
investment_col = 'Investment Amount (In Lakhs INR)'
debt_col = 'Debt (In lakhs INR)'

# Clean Equity Percentage
df['Equity (%)'] = df['Equity'].str.replace('%', '', regex=False).astype(float)

# Convert Investment & Debt from Lakhs to INR
df['Investment (INR)'] = pd.to_numeric(df[investment_col], errors='coerce') * 100000
df['Debt (INR)'] = pd.to_numeric(df[debt_col], errors='coerce') * 100000

# Convert Investor Decisions to 1 (Y) / 0 (N)
investor_cols = ['Anupam', 'Ashneer', 'Namita', 'Aman', 'Peyush', 'Vineeta', 'Ghazal']
df[investor_cols] = df[investor_cols].applymap(lambda x: 1 if str(x).strip().upper() == 'Y' else 0)

# Total Investors
df['Total Investors'] = df[investor_cols].sum(axis=1)

# Categorize Equity %
def equity_category(equity):
    if pd.isna(equity):
        return 'Unknown'
    elif equity < 10:
        return 'Low (<10%)'
    elif 10 <= equity <= 25:
        return 'Medium (10–25%)'
    else:
        return 'High (>25%)'

df['Equity Category'] = df['Equity (%)'].apply(equity_category)

# Final cleaned dataframe
df_cleaned = df[['Brand', 'Idea', 'Season', 'Investment (INR)', 'Debt (INR)', 'Equity (%)',
                 'Equity Category', 'Total Investors'] + investor_cols]

# Save to file
#df_cleaned.to_csv("Cleaned_Dataset.csv", index=False)
#print("Cleaned data saved to 'Cleaned_Dataset.csv'")

#  Equity vs Investors :
sns.boxplot(data=df_cleaned, x='Equity Category', y='Investment (INR)')
plt.title('Equity Category vs Investment Amount')
plt.show()

# Domains assigned
def classify_domain(idea):
    idea = str(idea).lower()
    if 'food' in idea or 'drink' in idea or 'beverage' in idea:
        return 'Food & Beverage'
    elif 'health' in idea or 'wellness' in idea or 'fitness' in idea:
        return 'Health & Wellness'
    elif 'tech' in idea or 'app' in idea or 'software' in idea:
        return 'Technology'
    elif 'fashion' in idea or 'apparel' in idea or 'wear' in idea:
        return 'Fashion'
    elif 'education' in idea or 'learning' in idea:
        return 'EdTech'
    else:
        return 'Other'

df_cleaned['Domain'] = df_cleaned['Idea'].apply(classify_domain)

# Total funding by domain
domain_funding = df_cleaned.groupby('Domain')['Investment (INR)'].sum().sort_values(ascending=False)
print(domain_funding)

df_cleaned.to_csv("Final_Tableau_Ready.csv", index=False)